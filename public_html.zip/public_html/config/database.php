<?php
/**
 * Configuración de Base de Datos - Sistema de Condominios
 */

// Prevenir acceso directo
if (!defined('SECURE_ACCESS')) {
    define('SECURE_ACCESS', true);
}

class Database {
    private static $connection = null;
    
    // Opciones de conexión PDO
    private const OPTIONS = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_spanish_ci"
    ];
    
    /**
     * Obtener conexión a la base de datos
     */
    public static function getConnection() {
        if (self::$connection === null) {
            try {
                // Cargar variables de entorno
                self::loadEnvVariables();
                
                $host = $_ENV['DB_HOST'] ?? 'srv645.hstgr.io';
                $dbname = $_ENV['DB_NAME'] ?? 'u837350477_Cuestionario';
                $username = $_ENV['DB_USER'] ?? 'u837350477_DEV';
                $password = $_ENV['DB_PASS'] ?? 'Farid123#warframe#pepillo';
                $port = $_ENV['DB_PORT'] ?? '3306';
                $charset = $_ENV['DB_CHARSET'] ?? 'utf8mb4';
                
                $dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset={$charset}";
                self::$connection = new PDO($dsn, $username, $password, self::OPTIONS);
                
            } catch (PDOException $e) {
                error_log("Error de conexión a BD: " . $e->getMessage());
                throw new Exception("Error de conexión a la base de datos: " . $e->getMessage());
            }
        }
        
        return self::$connection;
    }
    
    /**
     * Cargar variables de entorno desde archivo .env
     */
    private static function loadEnvVariables() {
        $envFile = __DIR__ . '/../.env';
        
        if (file_exists($envFile)) {
            $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            
            foreach ($lines as $line) {
                $line = trim($line);
                
                // Ignorar comentarios y líneas vacías
                if (empty($line) || $line[0] === '#') {
                    continue;
                }
                
                // Buscar = en la línea
                if (strpos($line, '=') === false) {
                    continue;
                }
                
                list($key, $value) = explode('=', $line, 2);
                
                $key = trim($key);
                $value = trim($value);
                
                // Remover comillas si existen
                if ((substr($value, 0, 1) === '"' && substr($value, -1) === '"') ||
                    (substr($value, 0, 1) === "'" && substr($value, -1) === "'")) {
                    $value = substr($value, 1, -1);
                }
                
                $_ENV[$key] = $value;
                putenv("$key=$value");
            }
        }
    }
    
    /**
     * Cerrar conexión
     */
    public static function close() {
        self::$connection = null;
    }
}
?>
