<?php
/**
 * API de Autenticación - Sistema de Condominios
 */

// Definir acceso seguro
define('SECURE_ACCESS', true);

// Cargar configuración de seguridad
require_once __DIR__ . '/../config/security.php';
SecurityConfig::loadConfig();

// Headers de seguridad
SecurityConfig::setSecurityHeaders();
header('Content-Type: application/json; charset=utf-8');

// Iniciar sesión
session_start();

// Cargar dependencias
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/crypto.php';
require_once 'Models.php';

/**
 * Clase para manejar autenticación
 */
class AuthController {
    
    /**
     * Procesar solicitudes de autenticación
     */
    public static function handleRequest() {
        try {
            $method = $_SERVER['REQUEST_METHOD'];
            $action = $_GET['action'] ?? '';
            
            // Validar método HTTP
            if (!in_array($method, ['GET', 'POST'])) {
                throw new Exception('Método no permitido', 405);
            }
            
            // Enrutar según la acción
            switch ($action) {
                case 'login_admin':
                    if ($method !== 'POST') {
                        throw new Exception('Método no permitido para login', 405);
                    }
                    return self::loginAdmin();
                    
                case 'login_resident':
                    if ($method !== 'POST') {
                        throw new Exception('Método no permitido para login', 405);
                    }
                    return self::loginResident();
                    
                case 'register_admin':
                    if ($method !== 'POST') {
                        throw new Exception('Método no permitido para registro', 405);
                    }
                    return self::registerAdmin();
                    
                case 'register_resident':
                    if ($method !== 'POST') {
                        throw new Exception('Método no permitido para registro', 405);
                    }
                    return self::registerResident();
                    
                case 'logout':
                    return self::logout();
                    
                case 'check_session':
                    return self::checkSession();
                    
                case 'get_condominios':
                    return self::getCondominios();
                    
                case 'get_calles':
                    return self::getCalles();
                    
                case 'get_casas':
                    return self::getCasas();
                    
                case 'get_empleados':
                    return self::getEmpleados();
                    
                case 'create_condominio':
                    if ($method !== 'POST') {
                        throw new Exception('Método no permitido para crear condominio', 405);
                    }
                    return self::createCondominio();
                    
                case 'create_calle':
                    if ($method !== 'POST') {
                        throw new Exception('Método no permitido para crear calle', 405);
                    }
                    return self::createCalle();
                    
                case 'create_casa':
                    if ($method !== 'POST') {
                        throw new Exception('Método no permitido para crear casa', 405);
                    }
                    return self::createCasa();
                    
                case 'debug_auth':
                    if (!SecurityConfig::isDebugMode()) {
                        throw new Exception('Debug no disponible en producción', 403);
                    }
                    return self::debugAuth();
                    
                default:
                    throw new Exception('Acción no válida', 400);
            }
            
        } catch (Exception $e) {
            return self::errorResponse($e->getMessage(), $e->getCode() ?: 500);
        }
    }
    
    /**
     * Login de administrador
     */
    private static function loginAdmin() {
        $data = self::getPostData();
        
        // Validar datos requeridos
        if (empty($data['email']) || empty($data['password'])) {
            throw new Exception('Email y contraseña son requeridos', 400);
        }
        
        // Validar formato de email
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            throw new Exception('Formato de email inválido', 400);
        }
        
        // Autenticar administrador
        $admin = Admin::authenticate($data['email'], $data['password']);
        
        if (!$admin) {
            // Debug información en modo desarrollo
            $debugInfo = '';
            if (SecurityConfig::isDebugMode()) {
                $testAdmin = Admin::findByEmail($data['email']);
                if ($testAdmin) {
                    $debugInfo = ' - Usuario encontrado pero contraseña incorrecta';
                    error_log("Debug Login: Usuario encontrado para email: " . $data['email']);
                    error_log("Debug Login: Hash en BD: " . substr($testAdmin->getAttribute('contrasena'), 0, 50) . "...");
                } else {
                    $debugInfo = ' - Usuario no encontrado con email: ' . $data['email'];
                    error_log("Debug Login: Usuario NO encontrado para email: " . $data['email']);
                }
            }
            throw new Exception('Credenciales inválidas' . $debugInfo, 401);
        }
        
        // Obtener datos desencriptados para la sesión
        $adminData = $admin->toArray();
        
        // Crear sesión
        $_SESSION['user_type'] = 'admin';
        $_SESSION['user_id'] = $admin->getAttribute('id_admin');
        $_SESSION['user_email'] = $adminData['correo']; // Email desencriptado
        $_SESSION['user_name'] = $admin->getAttribute('nombres') . ' ' . $admin->getAttribute('apellido1');
        
        return self::successResponse([
            'message' => 'Login exitoso',
            'data' => [
                'user' => $adminData,
                'condominios' => $admin->getCondominios()
            ]
        ]);
    }
    
    /**
     * Login de residente
     */
    private static function loginResident() {
        $data = self::getPostData();
        
        // Validar datos requeridos
        if (empty($data['email']) || empty($data['password'])) {
            throw new Exception('Email y contraseña son requeridos', 400);
        }
        
        // Validar formato de email
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            throw new Exception('Formato de email inválido', 400);
        }
        
        // Autenticar residente
        $persona = Persona::authenticate($data['email'], $data['password']);
        
        if (!$persona) {
            throw new Exception('Credenciales inválidas', 401);
        }
        
        // Crear sesión
        $_SESSION['user_type'] = 'resident';
        $_SESSION['user_id'] = $persona->getAttribute('id_persona');
        $_SESSION['user_email'] = $persona->getAttribute('correo_electronico');
        $_SESSION['user_name'] = $persona->getAttribute('nombres') . ' ' . $persona->getAttribute('apellido1');
        $_SESSION['is_admin'] = $persona->isAdmin();
        
        return self::successResponse([
            'message' => 'Login exitoso',
            'user' => $persona->toArray(),
            'casa' => $persona->getCasa(),
            'is_admin' => $persona->isAdmin()
        ]);
    }
    
    /**
     * Registro de administrador
     */
    private static function registerAdmin() {
        $data = self::getPostData();
        
        // Validar datos requeridos
        $required = ['nombres', 'apellido1', 'correo', 'contrasena'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                throw new Exception("El campo {$field} es requerido", 400);
            }
        }
        
        // Validar formato de email
        if (!filter_var($data['correo'], FILTER_VALIDATE_EMAIL)) {
            throw new Exception('Formato de email inválido', 400);
        }
        
        // Validar longitud de contraseña
        if (strlen($data['contrasena']) < 6) {
            throw new Exception('La contraseña debe tener al menos 6 caracteres', 400);
        }
        
        // Crear administrador
        $admin = Admin::createAdmin($data);
        
        return self::successResponse([
            'message' => 'Administrador registrado exitosamente',
            'user' => $admin->toArray()
        ]);
    }
    
    /**
     * Registro de residente
     */
    private static function registerResident() {
        $data = self::getPostData();
        
        // Validar datos requeridos
        $required = ['nombres', 'apellido1', 'correo_electronico', 'contrasena', 'curp'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                throw new Exception("El campo {$field} es requerido", 400);
            }
        }
        
        // Validar formato de email
        if (!filter_var($data['correo_electronico'], FILTER_VALIDATE_EMAIL)) {
            throw new Exception('Formato de email inválido', 400);
        }
        
        // Validar CURP (18 caracteres)
        if (strlen($data['curp']) !== 18) {
            throw new Exception('CURP debe tener 18 caracteres', 400);
        }
        
        // Validar longitud de contraseña
        if (strlen($data['contrasena']) < 6) {
            throw new Exception('La contraseña debe tener al menos 6 caracteres', 400);
        }
        
        // Crear residente
        $persona = Persona::createResident($data);
        
        return self::successResponse([
            'message' => 'Residente registrado exitosamente',
            'user' => $persona->toArray()
        ]);
    }
    
    /**
     * Cerrar sesión
     */
    private static function logout() {
        session_destroy();
        return self::successResponse(['message' => 'Sesión cerrada exitosamente']);
    }
    
    /**
     * Verificar sesión activa
     */
    private static function checkSession() {
        if (!isset($_SESSION['user_type']) || !isset($_SESSION['user_id'])) {
            throw new Exception('No hay sesión activa', 401);
        }
        
        return self::successResponse([
            'authenticated' => true,
            'user_type' => $_SESSION['user_type'],
            'user_id' => $_SESSION['user_id'],
            'user_email' => $_SESSION['user_email'] ?? '',
            'user_name' => $_SESSION['user_name'] ?? ''
        ]);
    }
    
    /**
     * Obtener condominios
     */
    private static function getCondominios() {
        $condominios = Condominio::getAll();
        return self::successResponse($condominios);
    }
    
    /**
     * Obtener calles de un condominio
     */
    private static function getCalles() {
        $condominioId = $_GET['condominio_id'] ?? '';
        
        if (empty($condominioId)) {
            throw new Exception('ID de condominio requerido', 400);
        }
        
        $condominio = Condominio::find($condominioId);
        if (!$condominio) {
            throw new Exception('Condominio no encontrado', 404);
        }
        
        $calles = $condominio->getCalles();
        return self::successResponse($calles);
    }
    
    /**
     * Obtener casas de un condominio
     */
    private static function getCasas() {
        $condominioId = $_GET['condominio_id'] ?? '';
        
        if (empty($condominioId)) {
            throw new Exception('ID de condominio requerido', 400);
        }
        
        $condominio = Condominio::find($condominioId);
        if (!$condominio) {
            throw new Exception('Condominio no encontrado', 404);
        }
        
        $casas = $condominio->getCasas();
        return self::successResponse($casas);
    }
    
    /**
     * Obtener empleados de un condominio
     */
    private static function getEmpleados() {
        $condominioId = $_GET['condominio_id'] ?? '';
        
        if (empty($condominioId)) {
            throw new Exception('ID de condominio requerido', 400);
        }
        
        try {
            $db = Database::getConnection();
            $sql = "SELECT * FROM empleados_condominio WHERE id_condominio = :id_condominio ORDER BY nombres";
            $stmt = $db->prepare($sql);
            $stmt->execute(['id_condominio' => $condominioId]);
            $empleados = $stmt->fetchAll();
            
            return self::successResponse($empleados);
        } catch (PDOException $e) {
            error_log("Error al obtener empleados: " . $e->getMessage());
            throw new Exception('Error al obtener empleados', 500);
        }
    }
    
    /**
     * Obtener datos POST de forma segura (soporta JSON y FormData)
     */
    private static function getPostData() {
        // Verificar si es FormData
        if (!empty($_POST)) {
            return $_POST;
        }
        
        // Si no hay $_POST, intentar JSON
        $input = file_get_contents('php://input');
        if (empty($input)) {
            return [];
        }
        
        $data = json_decode($input, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Datos inválidos', 400);
        }
        
        return $data ?: [];
    }
    
    /**
     * Respuesta de éxito
     */
    private static function successResponse($data = null) {
        http_response_code(200);
        echo json_encode([
            'success' => true,
            'data' => $data
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    /**
     * Crear condominio
     */
    private static function createCondominio() {
        $data = self::getPostData();
        
        // Validar datos requeridos
        if (empty($data['nombre']) || empty($data['direccion'])) {
            throw new Exception('Nombre y dirección son requeridos', 400);
        }
        
        $condominio = new Condominio();
        $result = $condominio->create([
            'nombre' => trim($data['nombre']),
            'direccion' => trim($data['direccion'])
        ]);
        
        if ($result) {
            self::successResponse(['id' => $result, 'message' => 'Condominio creado exitosamente']);
        } else {
            throw new Exception('Error al crear condominio');
        }
    }
    
    /**
     * Crear calle
     */
    private static function createCalle() {
        $data = self::getPostData();
        
        // Validar datos requeridos
        if (empty($data['id_condominio']) || empty($data['nombre'])) {
            throw new Exception('ID de condominio y nombre son requeridos', 400);
        }
        
        $calle = new Calle();
        $result = $calle->create([
            'id_condominio' => (int)$data['id_condominio'],
            'nombre' => trim($data['nombre']),
            'descripcion' => trim($data['descripcion'] ?? '')
        ]);
        
        if ($result) {
            self::successResponse(['id' => $result, 'message' => 'Calle creada exitosamente']);
        } else {
            throw new Exception('Error al crear calle');
        }
    }
    
    /**
     * Crear casa
     */
    private static function createCasa() {
        $data = self::getPostData();
        
        // Validar datos requeridos
        if (empty($data['id_condominio']) || empty($data['id_calle']) || empty($data['casa'])) {
            throw new Exception('ID de condominio, ID de calle y número de casa son requeridos', 400);
        }
        
        $casa = new Casa();
        $result = $casa->create([
            'id_condominio' => (int)$data['id_condominio'],
            'id_calle' => (int)$data['id_calle'],
            'casa' => trim($data['casa'])
        ]);
        
        if ($result) {
            self::successResponse(['id' => $result, 'message' => 'Casa creada exitosamente']);
        } else {
            throw new Exception('Error al crear casa');
        }
    }
    
    /**
     * Debug de autenticación
     */
    private static function debugAuth() {
        $data = self::getPostData();
        
        if (empty($data['email'])) {
            throw new Exception('Email requerido para debug', 400);
        }
        
        $email = $data['email'];
        $password = $data['password'] ?? '';
        
        // Buscar usuario
        $admin = Admin::findByEmail($email);
        
        $debug = [
            'email_buscado' => $email,
            'usuario_encontrado' => $admin ? true : false,
            'password_proporcionada' => !empty($password)
        ];
        
        if ($admin) {
            $debug['datos_usuario'] = [
                'id' => $admin->getAttribute('id_admin'),
                'nombres' => $admin->getAttribute('nombres'),
                'email_en_bd' => substr($admin->getAttribute('correo'), 0, 50) . '...',
                'password_hash' => substr($admin->getAttribute('contrasena'), 0, 50) . '...'
            ];
            
            if (!empty($password)) {
                $debug['verificacion_password'] = $admin->verifyPassword($password);
            }
        }
        
        return self::successResponse($debug);
    }
    
    /**
     * Respuesta de error
     */
    private static function errorResponse($message, $code = 500) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'error' => $message
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// Procesar la solicitud
AuthController::handleRequest();
?>
