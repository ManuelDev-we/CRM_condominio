<?php
/**
 * Modelos para el Sistema de Condominios
 */

require_once 'BaseModel.php';
require_once __DIR__ . '/../config/crypto.php';

/**
 * Modelo para Administradores
 */
class Admin extends BaseModel {
    protected $table = 'admin';
    protected $primaryKey = 'id_admin';
    protected $fillable = [
        'nombres', 'apellido1', 'apellido2', 'correo', 'contrasena'
    ];
    
    /**
     * Buscar administrador por correo
     */
    public static function findByEmail($email) {
        $db = Database::getConnection();
        
        // Primero intentar buscar el email sin cifrar (para compatibilidad)
        $sql = "SELECT * FROM admin WHERE correo = :email LIMIT 1";
        $stmt = $db->prepare($sql);
        $stmt->execute(['email' => $email]);
        $data = $stmt->fetch();
        
        // Si no se encuentra, intentar con email cifrado
        if (!$data) {
            try {
                $encryptedEmail = CryptoUtils::encryptEmail($email);
                $stmt = $db->prepare($sql);
                $stmt->execute(['email' => $encryptedEmail]);
                $data = $stmt->fetch();
            } catch (Exception $e) {
                // Si falla el cifrado, continuar con la búsqueda normal
            }
        }
        
        if ($data) {
            $admin = new static();
            $admin->attributes = $data;
            return $admin;
        }
        
        return null;
    }
    
    /**
     * Autenticar administrador
     */
    public static function authenticate($email, $password) {
        $admin = static::findByEmail($email);
        
        if ($admin && $admin->verifyPassword($password)) {
            return $admin;
        }
        
        return null;
    }
    
    /**
     * Verificar contraseña
     */
    public function verifyPassword($password) {
        $hashedPassword = $this->getAttribute('contrasena');
        
        // Intentar primero con verificación tradicional (para contraseñas creadas antes del pepper)
        if (password_verify($password, $hashedPassword)) {
            return true;
        }
        
        // Si falla, intentar con el nuevo sistema (pepper)
        try {
            return CryptoUtils::verifyPassword($password, $hashedPassword);
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Crear nuevo administrador
     */
    public static function createAdmin($data) {
        $admin = new static();
        
        // Validar datos requeridos
        $required = ['nombres', 'apellido1', 'correo', 'contrasena'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                throw new Exception("El campo {$field} es requerido");
            }
        }
        
        // Validar email único
        if (static::findByEmail($data['correo'])) {
            throw new Exception("El correo electrónico ya está registrado");
        }
        
        // Cifrar email
        $data['correo'] = CryptoUtils::encryptEmail($data['correo']);
        
        // Hash de la contraseña con pepper
        $data['contrasena'] = CryptoUtils::hashPassword($data['contrasena']);
        
        $admin->fill($data);
        
        if ($admin->save()) {
            return $admin;
        }
        
        throw new Exception("Error al crear el administrador");
    }
    
    /**
     * Obtener condominios asignados al admin
     */
    public function getCondominios() {
        $sql = "SELECT c.* FROM condominios c 
                INNER JOIN admin_cond ac ON c.id_condominio = ac.id_condominio 
                WHERE ac.id_admin = :id_admin";
        
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['id_admin' => $this->getAttribute('id_admin')]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error al obtener condominios: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Convertir a array desencriptando datos sensibles
     */
    public function toArray() {
        $data = $this->attributes;
        
        // Desencriptar email si está cifrado
        if (isset($data['correo'])) {
            try {
                // Intentar desencriptar
                $decryptedEmail = CryptoUtils::decryptEmail($data['correo']);
                // Verificar si el resultado es un email válido
                if (filter_var($decryptedEmail, FILTER_VALIDATE_EMAIL)) {
                    $data['correo'] = $decryptedEmail;
                }
                // Si no es un email válido después del descifrado, mantener el original
            } catch (Exception $e) {
                // Si no se puede desencriptar, asumir que ya está en texto plano
                // Esto maneja la compatibilidad con datos no cifrados
            }
        }
        
        // Nunca devolver la contraseña
        unset($data['contrasena']);
        
        return $data;
    }
}

/**
 * Modelo para Residentes/Personas
 */
class Persona extends BaseModel {
    protected $table = 'personas';
    protected $primaryKey = 'id_persona';
    protected $fillable = [
        'id_casa', 'id_condominio', 'id_calle', 'nombres', 'apellido1', 
        'apellido2', 'contrasena', 'correo_electronico', 'fecha_nacimiento', 
        'jerarquia', 'curp'
    ];
    
    /**
     * Buscar persona por correo
     */
    public static function findByEmail($email) {
        return static::where('correo_electronico', $email);
    }
    
    /**
     * Autenticar residente
     */
    public static function authenticate($email, $password) {
        $persona = static::findByEmail($email);
        
        if ($persona && $persona->verifyPassword($password)) {
            return $persona;
        }
        
        return null;
    }
    
    /**
     * Crear nuevo residente
     */
    public static function createResident($data) {
        $persona = new static();
        
        // Validar datos requeridos
        $required = ['nombres', 'apellido1', 'correo_electronico', 'contrasena', 'curp'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                throw new Exception("El campo {$field} es requerido");
            }
        }
        
        // Validar email único
        if (static::findByEmail($data['correo_electronico'])) {
            throw new Exception("El correo electrónico ya está registrado");
        }
        
        // Hash de la contraseña
        $data['contrasena'] = password_hash($data['contrasena'], PASSWORD_DEFAULT);
        
        // Establecer jerarquía por defecto (0 = residente)
        if (!isset($data['jerarquia'])) {
            $data['jerarquia'] = 0;
        }
        
        $persona->fill($data);
        
        if ($persona->save()) {
            return $persona;
        }
        
        throw new Exception("Error al crear el residente");
    }
    
    /**
     * Verificar si es administrador
     */
    public function isAdmin() {
        return $this->getAttribute('jerarquia') == 1;
    }
    
    /**
     * Obtener información de la casa
     */
    public function getCasa() {
        $sql = "SELECT cas.*, cal.nombre as nombre_calle, con.nombre as nombre_condominio
                FROM casas cas
                INNER JOIN calles cal ON cas.id_calle = cal.id_calle
                INNER JOIN condominios con ON cas.id_condominio = con.id_condominio
                WHERE cas.id_casa = :id_casa";
        
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['id_casa' => $this->getAttribute('id_casa')]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error al obtener casa: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Convertir a array desencriptando datos sensibles
     */
    public function toArray() {
        $data = $this->attributes;
        
        // Desencriptar email si está cifrado
        if (isset($data['correo_electronico'])) {
            try {
                $data['correo_electronico'] = CryptoUtils::decryptEmail($data['correo_electronico']);
            } catch (Exception $e) {
                // Si no se puede desencriptar, mantener el valor original
                // Esto maneja la compatibilidad con datos no cifrados
            }
        }
        
        // Nunca devolver la contraseña
        unset($data['contrasena']);
        
        return $data;
    }
}

/**
 * Modelo para Condominios
 */
class Condominio extends BaseModel {
    protected $table = 'condominios';
    protected $primaryKey = 'id_condominio';
    protected $fillable = ['nombre', 'direccion'];
    
    /**
     * Obtener todas las calles del condominio
     */
    public function getCalles() {
        $sql = "SELECT * FROM calles WHERE id_condominio = :id_condominio";
        
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['id_condominio' => $this->getAttribute('id_condominio')]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error al obtener calles: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Obtener todas las casas del condominio
     */
    public function getCasas() {
        $sql = "SELECT cas.*, cal.nombre as nombre_calle
                FROM casas cas
                INNER JOIN calles cal ON cas.id_calle = cal.id_calle
                WHERE cas.id_condominio = :id_condominio";
        
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['id_condominio' => $this->getAttribute('id_condominio')]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error al obtener casas: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Obtener todos los condominios
     */
    public static function getAll() {
        $instance = new static();
        $sql = "SELECT * FROM condominios ORDER BY nombre";
        
        try {
            $stmt = $instance->db->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error al obtener condominios: " . $e->getMessage());
            return [];
        }
    }
}

/**
 * Modelo para Calles
 */
class Calle extends BaseModel {
    protected $table = 'calles';
    protected $primaryKey = 'id_calle';
    protected $fillable = ['id_condominio', 'nombre', 'descripcion'];
    
    /**
     * Obtener condominio al que pertenece
     */
    public function getCondominio() {
        $sql = "SELECT * FROM condominios WHERE id_condominio = :id_condominio";
        
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['id_condominio' => $this->getAttribute('id_condominio')]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error al obtener condominio: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Obtener casas de la calle
     */
    public function getCasas() {
        $sql = "SELECT * FROM casas WHERE id_calle = :id_calle";
        
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['id_calle' => $this->getAttribute('id_calle')]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error al obtener casas: " . $e->getMessage());
            return [];
        }
    }
}

/**
 * Modelo para Casas
 */
class Casa extends BaseModel {
    protected $table = 'casas';
    protected $primaryKey = 'id_casa';
    protected $fillable = ['id_condominio', 'id_calle', 'casa'];
    
    /**
     * Obtener condominio al que pertenece
     */
    public function getCondominio() {
        $sql = "SELECT * FROM condominios WHERE id_condominio = :id_condominio";
        
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['id_condominio' => $this->getAttribute('id_condominio')]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error al obtener condominio: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Obtener calle a la que pertenece
     */
    public function getCalle() {
        $sql = "SELECT * FROM calles WHERE id_calle = :id_calle";
        
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute(['id_calle' => $this->getAttribute('id_calle')]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error al obtener calle: " . $e->getMessage());
            return null;
        }
    }
}
?>
